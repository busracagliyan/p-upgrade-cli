#!/usr/bin/python3
import shutil
import gi
import locale
import subprocess
import os
from locale import gettext as _
import warnings
warnings.filterwarnings("ignore")

gi.require_version("GLib", "2.0")
gi.require_version("Gtk", "3.0")
gi.require_version("Vte", "2.91")
gi.require_version('Notify', '0.7')
from gi.repository import Gtk, Gdk, Vte, GLib,Notify

from Package import Package
from Check import Check

# Translation constants
APPNAME = 'pardus-upgrade'
TRANSLATIONS_PATH = "/usr/share/locale"
SYSTEM_LANGUAGE = os.environ.get("LANG")

# Translation functions
locale.bindtextdomain(APPNAME, TRANSLATIONS_PATH)
locale.textdomain(APPNAME)
locale.setlocale(locale.LC_ALL, SYSTEM_LANGUAGE)


class MainWindow():
    def __init__(self, application):

        self.application = application

        MainWindowUiFile = os.path.dirname(
            os.path.abspath(__file__)) + "/../ui/MainWindow.glade"
        self.builder = Gtk.Builder()
        self.builder.set_translation_domain(APPNAME)
        self.builder.add_from_file(MainWindowUiFile)
        self.window = self.builder.get_object("main_window")
        self.window.connect("destroy", self.onDestroy)

        self.define_components()

        self.window.set_title(_("Pardus Upgrade"))
        # icon
        self.window.set_icon_name("upgrade-icon")

        self.upgrade_btn.connect("clicked", self.upgrade_button_func)
        self.version_upgrade_btn.connect(
            "clicked", self.version_upgrade_button_func)
        self.exit_btn.connect("clicked", self.onDestroy)
        #self.fix_upgrade_btn.connect("clicked", self.fix_upgrade_button_func)
        #self.fix_version_upgrade_btn.connect("clicked", self.fix_version_upgrade_button_func)
        self.restart_btn.connect("clicked", self.restart_button_func)

        self.vteterm = Vte.Terminal()
        self.vteterm.set_scrollback_lines(-1)
        menu = Gtk.Menu()
        menu_items = Gtk.MenuItem(label=_("Copy selected text"))
        menu.append(menu_items)
        menu_items.connect("activate", self.menu_action, self.vteterm)
        menu_items.show()
        self.vteterm.connect_object("event", self.vte_event, menu)
        self.vtebox.add(self.vteterm)

        self.check = Check()
        self.version_check = self.check.check_version()
        self.sourceslist_check = self.check.check_sourceslist()

        self.window.show_all()
        self.aptUpdate()

    def define_components(self):
        # stacks
        self.main_stack = self.builder.get_object("main_stack")
        self.pages_stack = self.builder.get_object("pages_stack")
        self.ready_stack = self.builder.get_object("ready_stack")
        self.button_stack = self.builder.get_object("button_stack")
        self.pkg_name_stack = self.builder.get_object("pkg_name_stack")

        # stack pages
        self.page_upgraded = self.builder.get_object("page_upgraded")
        self.page_new = self.builder.get_object("page_new")
        self.page_removed = self.builder.get_object("page_removed")
        self.page_kept = self.builder.get_object("page_kept")
        self.page_broken = self.builder.get_object("page_broken")

        # stack pages names
        self.page_upgraded.name = _("Upgraded")
        self.page_new.name = _("Newly Installed")
        self.page_removed.name = _("Removed")
        self.page_kept.name = _("Not Upgraded")
        self.page_broken.name = _("Broken")

        # labels
        self.space_text = self.builder.get_object("space_label")
        self.upgradable_text = self.builder.get_object("upgradable_text")
        self.check_title = self.builder.get_object("check_title_label")
        self.check_text = self.builder.get_object("check_text_label")
        self.upgraded_label = self.builder.get_object("upgraded_label")
        self.added_label = self.builder.get_object("added_label")
        self.removed_label = self.builder.get_object("removed_label")
        self.kept_label = self.builder.get_object("kept_label")
        self.broken_label = self.builder.get_object("broken_label")
        self.message_title = self.builder.get_object("message_title")
        self.message_text = self.builder.get_object("message_label")

        self.splashspinner = self.builder.get_object("splashspinner")

        # buttons
        self.upgrade_btn = self.builder.get_object("upgrade_button")
        self.version_upgrade_btn = self.builder.get_object("version_upgrade_button")
        self.exit_btn = self.builder.get_object("exit_button")
        self.fix_upgrade_btn = self.builder.get_object("fix_upgrade_button")
        self.fix_version_upgrade_btn = self.builder.get_object("fix_version_upgrade_button")
        self.restart_btn = self.builder.get_object("restart_button")

        self.vtebox = self.builder.get_object("vtebox")
        self.errormessage = ""
        self.state = False
        self.isbroken = False

    def upgrade_button_func(self, widget):
        self.message_title.set_text("Upgrading packages")
        self.message_text.set_text("This process may take time.")
        command = ["/usr/bin/pkexec",
                   os.path.dirname(os.path.abspath(__file__)) + "/Actions.py", "upgrade"]
        pid = self.startVteProcess(command)

    def version_upgrade_button_func(self, widget):
        self.message_title.set_text("Upgrading from Pardus 19 to Pardus 21")
        self.message_text.set_text("Adding necesssary packages. This process may take time")
        self.state = True
        command = ["/usr/bin/pkexec",
                   os.path.dirname(os.path.abspath(__file__)) + "/Actions.py", "upgrade-version"]
        pid = self.startVteProcess(command)

    """def fix_upgrade_button_func(self, widget):
        self.message_title.set_text("Upgrading packages")
        self.message_text.set_text("This process may take time.")
        command = ["/usr/bin/pkexec",
                   os.path.dirname(os.path.abspath(__file__)) + "/Actions.py", "fixandupgrade"]
        pid = self.startVteProcess(command)

    def fix_version_upgrade_button_func(self,widget):
        self.message_title.set_text("Upgrading from Pardus 19 to Pardus 21")
        self.message_text.set_text("Adding necesssary packages. This process may take time")
        self.state = True
        command = ["/usr/bin/pkexec",
                   os.path.dirname(os.path.abspath(__file__)) + "/Actions.py", "fixandversionupgrade"]
        pid = self.startVteProcess(command)"""

    def restart_button_func(self, widget):
        subprocess.call(["/sbin/reboot"])

    def onDestroy(self, widget):
        self.window.get_application().quit()

    def check_memory(self):
        total, used, free = shutil.disk_usage("/")
        return total,used,free

    def aptUpdate(self):       
        self.pages_stack.set_visible_child_name("spinner_page")
        self.splashspinner.start()
        self.check_title.set_text(_("checking packages for updates"))
        self.check_text.set_text(_("calculating package sizes to add...")) 
        self.package()
        command = ["/usr/bin/pkexec",os.path.dirname(os.path.abspath(__file__)) + "/AutoAptUpdate.py"]
        self.startAptUpdateProcess(command)

    def startAptUpdateProcess(self, params):
        pid, stdin, stdout, stderr = GLib.spawn_async(params, flags=GLib.SpawnFlags.DO_NOT_REAP_CHILD,
                                                      standard_output=True, standard_error=True)
        GLib.io_add_watch(GLib.IOChannel(stdout), GLib.IO_IN | GLib.IO_HUP, self.onAptUpdateProcessStdout)
        GLib.io_add_watch(GLib.IOChannel(stderr), GLib.IO_IN | GLib.IO_HUP, self.onAptUpdateProcessStderr)
        GLib.child_watch_add(GLib.PRIORITY_DEFAULT, pid, self.onAptUpdateProcessExit)

        return pid

    def onAptUpdateProcessStdout(self, source, condition):
        if condition == GLib.IO_HUP:
            return False
        line = source.readline()
        print(line)
        return True

    def onAptUpdateProcessStderr(self, source, condition):
        if condition == GLib.IO_HUP:
            return False
        line = source.readline()
        print(line)
        return True

    def onAptUpdateProcessExit(self, pid, status):
        self.splashspinner.stop()
        print(status)
        if status == 0:
            self.pages_stack.set_visible_child_name("sourcelist_page")
            self.startProcess() 
        elif status == 32256:
            self.window.get_application().quit()
        else:
            self.pages_stack.set_visible_child_name("spinner_page")

    def vte_event(self, widget, event):
        if event.type == Gdk.EventType.BUTTON_PRESS:
            if event.button.button == 3:
                widget.popup_for_device(None, None, None, None, None,
                                        event.button.button, event.time)
                return True
        return False

    def menu_action(self, widget, terminal):
        terminal.copy_clipboard()

    def startVteProcess(self, params):
        self.pages_stack.set_visible_child_name("vtebox_page")
        status, pid = self.VteTerminal(self.vteterm, params)
        return pid

    def onVteDone(self, obj, status):
        if status == 32256:
            self.pages_stack.set_visible_child_name("sourcelist_page")
        else:
            self.pages_stack.set_visible_child_name("ready_page1")
            if self.state:
                self.ready_stack.set_visible_child_name("ready_page2")
            else:
                self.ready_stack.set_visible_child_name("ready_page3")

    def VteTerminal(self, term, command):
        pty = Vte.Pty.new_sync(Vte.PtyFlags.DEFAULT)
        term.set_pty(pty)
        term.connect("child-exited", self.onVteDone)
        return term.spawn_sync(Vte.PtyFlags.DEFAULT,
                               os.environ['HOME'],
                               command,
                               [],
                               GLib.SpawnFlags.DO_NOT_REAP_CHILD,
                               None,
                               None,
                               )

    def packages_list(self, array):
            lst = ""
            for i in array:
                lst += i + "\n"
            return lst
    
    def show_packages(self,package,label,page):
        if len(package) !=0 and  package != None:
            page.set_visible(True)
            label.set_text(self.packages_list(package))
        else:
            page.set_visible(False)

    def startProcess(self):
        self.upgraded_pkg, self.new_pkg, self.removed_pkg, self.kept_pkg = self.Package.upgradable_package_check()
        self.broken = self.Package.broken_packages()

        self.page_upgraded.set_visible(False)
        self.page_new.set_visible(False)
        self.page_removed.set_visible(False)
        self.page_kept.set_visible(False)
        self.page_broken.set_visible(False)

        self.version_upgrade_btn.set_visible(False)     
        self.fix_version_upgrade_btn.set_visible(False)    

        download_size, required_space = self.Package.required_size()

        self.show_packages(self.upgraded_pkg,self.upgraded_label,self.page_upgraded)
        self.show_packages(self.new_pkg,self.added_label,self.page_new)
        self.show_packages(self.removed_pkg,self.removed_label,self.page_removed)
        self.show_packages(self.kept_pkg,self.kept_label,self.page_kept)

        total, used, free = self.check_memory()

        if total != used or  free< (download_size+required_space):
            print(_("There is no free space!")) 
            # self.check.notify("Disk Memory","There is no free space")
            self.space_text.set_text(_("There is no free space"))
            self.upgrade_btn.set_visible(False)
        else:
            print(_("there is enough free space"))
            # self.check.notify("Disk Memory","There is enough free space")#.set_urgency(Notify.URGENCY_CRITICAL)

            download_size = self.Package.beauty_size(download_size)
            required_space = self.Package.beauty_size(required_space)

            # print(download_size)
            # print(required_space)

            if download_size == "0.0 KB" and required_space == "0.0 KB":
                self.pages_stack.set_visible_child_name("ready_page1")
                self.ready_stack.set_visible_child_name("already_page")
                if self.version_check and self.sourceslist_check:
                    self.pages_stack.set_visible_child_name("sourcelist_page")
                    self.version_upgrade_btn.set_visible(True)
                    self.upgrade_btn.set_visible(False)
                    self.button_stack.set_visible_child_name("versionupgradepage")
                    #self.space_text.set_text(_(""))
                    self.upgradable_text.set_text(_("This version is upgradable from Pardus 19 to Pardus 21."))
            else:
                self.space_text.set_text(_("Need to get ") +str(download_size) + _(" of archives.") +
                    _(" After this operation, ") + str(required_space) + _(" of additional disk space will be used."))
                self.pages_stack.set_visible_child_name("sourcelist_page")

                string = (str(len(self.upgraded_pkg)) +  _(" upgraded, ")
                        +str(len(self.new_pkg))+ _(" newly installed, ")
                        + str(len(self.removed_pkg)) + _(" to remove, ")
                        + str(len(self.kept_pkg))) + _(" not upgraded")
                self.upgradable_text.set_text((string))

                if self.broken != None:
                    self.page_broken.set_visible(True)
                    self.show_packages(self.broken,self.broken_label,self.page_broken)
                    self.button_stack.set_visible_child_name("fixupgradepage")
                    self.upgradable_text.set_text(string + ", and " + str(len(self.broken)) + " broken" )
                    if self.version_check and self.sourceslist_check:
                        self.fix_version_upgrade_btn.set_visible(True)
                else:
                    self.button_stack.set_visible_child_name("versionupgradepage")
                    if self.version_check and self.sourceslist_check:
                        self.version_upgrade_btn.set_visible(True)            

    def package(self):
        print("starting")
        self.Package = Package()
        if self.Package.updatecache():
            self.isbroken = False
        else:
            self.isbroken = True
            print(_("Error while updating Cache"))

        print(_("package completed"))