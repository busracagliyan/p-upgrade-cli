#!/usr/bin/python3
import os, subprocess
import apt

def main():
    try:
        print("done!")
        cache = apt.Cache()
        cache.open()
        cache.update()
    except Exception as e:
        print(str(e))
        print("error!")
        subprocess.call(["apt", "update"],env={**os.environ, 'DEBIAN_FRONTEND': 'noninteractive'})


if __name__ == "__main__":
    main()