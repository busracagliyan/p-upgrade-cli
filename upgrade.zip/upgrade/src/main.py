#!/usr/bin/env python3
import gi
from MainWindow import *

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib

class Application(Gtk.Application):
    def __init__(self, application_id, flags):
        Gtk.Application.__init__(self, application_id=application_id,
                         flags=flags)

        self.connect("activate",self.activate)

    def activate(self,application):
        windows = self.get_windows()
        if (len(windows)>0):
            window = windows[0]
            window.present()
            window.show() 
        else:
            window = MainWindow(self)
            self.add_window(window.window)
            window.window.show()

if __name__ == "__main__":
    application = Application("tr.org.pardus.upgrade", Gio.ApplicationFlags.FLAGS_NONE)
    application.run()
