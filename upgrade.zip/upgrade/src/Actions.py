#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, sys
import subprocess
import apt, apt_pkg
import shutil
from pathlib import Path

def main():
    def control_lock():
        apt_pkg.init_system()
        try:
            apt_pkg.pkgsystem_lock()
        except SystemError:
            return False
        apt_pkg.pkgsystem_unlock()
        return True

    def update():
        subprocess.call(["apt", "update", "-o", "APT::Status-Fd=2"],
                        env={**os.environ, 'DEBIAN_FRONTEND': 'noninteractive'})

    def fixbroken():
        subprocess.call(["apt", "install", "--fix-broken", "-yq"],
                        env={**os.environ, 'DEBIAN_FRONTEND': 'noninteractive'})
    
    def dpkgconfigure():
        subprocess.call(["dpkg", "--configure", "-a"],
                        env={**os.environ, 'DEBIAN_FRONTEND': 'noninteractive'})

    def fullupgrade():
        subprocess.call(["apt", "full-upgrade", "-yq", "-o", "APT::Status-Fd=2"],
                        env={**os.environ, 'DEBIAN_FRONTEND': 'noninteractive'})

    def checkcorrectsourceslist():
        with open("/etc/apt/sources.list", "r") as file:
            sourceslist = file.read()

        source = ""
        for line in sourceslist.split("\n"):
            if "depo.pardus.org.tr" in line:
                if "onyedi" in line:
                    line = line.replace("onyedi", "ondokuz")
                if "ondokuz" in line:
                    line = line.replace("ondokuz", "yirmibir")
                """if "yirmibir" in line:
                    line = line.replace("yirmibir", "yirmiuc")"""
                source += line + "\n"
            else:
                source += line + "\n"

        tmpfile = "/etc/apt/sources.list.d/tmp/"
        if os.path.exists("/etc/apt/sources.list.d/*"):
            shutil.copy("/etc/apt/sources.list.d/",tmpfile, follow_symlinks=True)
        shutil.rmtree("/etc/apt/sources.list.d", ignore_errors=True)
        shutil.rmtree("/var/lib/apt/lists/", ignore_errors=True)
        Path("/etc/apt/sources.list.d").mkdir(parents=True, exist_ok=True)
        sfile = open("/etc/apt/sources.list", "w")
        sfile.write(source)
        sfile.flush()
        sfile.close()

    if len(sys.argv) > 1:
        if control_lock():
            if sys.argv[1] == "upgrade":
                update()
                fullupgrade()
            elif sys.argv[1] == "upgrade-version":
                update()
                fullupgrade()
                checkcorrectsourceslist()
                update()
                fullupgrade()
            elif sys.argv[1] == "fixandupgrade":
                update()
                fixbroken()
                dpkgconfigure()
                fullupgrade()
                """elif sys.argv[1] == "fixandversionupgrade":
                checkcorrectsourceslist()
                update()
                fixbroken()
                dpkgconfigure()
                fullupgrade()"""
            else:
                print("unknown argument error")
        else:
            print("lock error")
            sys.exit(1)
    else:
        print("no argument passed")


if __name__ == "__main__":
    main()