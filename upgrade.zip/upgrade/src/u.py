import shutil

total, used, free = shutil.disk_usage("/")

print("Total: %d MB" % (total // (10**9)))
print("Used: %d MB" % (used // (10**9)))
print("Free: %d MB" % (free // (10**9)))