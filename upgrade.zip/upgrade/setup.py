#!/usr/bin/env python3
from setuptools import setup, find_packages, os

changelog = 'debian/changelog'
if os.path.exists(changelog):
    head = open(changelog).readline()
    try:
        version = head.split("(")[1].split(")")[0]
    except:
        print("debian/changelog format is wrong for get version")
        version = ""
    f = open('src/__version__', 'w')
    f.write(version)
    f.close()

data_files = [
    ("/usr/share/applications/", ["tr.org.pardus.upgrade.desktop"]),
    ("/usr/share/locale/tr/LC_MESSAGES/", ["po/tr/LC_MESSAGES/upgrade.mo"]),
    ("/usr/share/pardus/upgrade/src", ["src/MainWindow.py", "src/Package.py", "src/Check.py","src/Actions.py", "src/main.py", "src/__version__"]),
    ("/usr/share/pardus/upgrade/ui", ["ui/MainWindow.glade"]),
    ("/usr/share/pardus/upgrade/icons", ["icons/pardus-icon.png","icons/upgrade-icon.png"]),
    ("/usr/share/polkit-1/actions", ["tr.org.pardus.pkexec.upgrade.policy"]),
    ("/usr/share/icons/hicolor/scalable/apps/", ["icons/pardus-icon.png","icons/upgrade-icon.png"]),
    ("/usr/bin/", ["upgrade"])
]

setup(
    name="upgrade",
    version=version,
    packages=find_packages(),
    scripts=["upgrade"],
    install_requires=["PyGObject"],
    data_files=data_files,
    author="Büşra Çağlıyan",
    author_email="busra.cagliyan@pardus.org.tr",
    description="This app was created to upgrade from Pardus 19 to Pardus 21.",
    license="GPLv3",
    keywords="upgrade",
    url="https://www.pardus.org.tr",
)
